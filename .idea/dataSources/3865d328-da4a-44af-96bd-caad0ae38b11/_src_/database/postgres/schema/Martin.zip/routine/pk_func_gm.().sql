create function "Martin".pk_func_gm() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_gm');
  RETURN new;
END;
$$
;
