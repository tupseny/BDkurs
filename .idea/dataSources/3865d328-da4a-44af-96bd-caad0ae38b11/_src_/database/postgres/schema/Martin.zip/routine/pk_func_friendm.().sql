create function "Martin".pk_func_friendm() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_friendm');
  RETURN new;
END;
$$
;
