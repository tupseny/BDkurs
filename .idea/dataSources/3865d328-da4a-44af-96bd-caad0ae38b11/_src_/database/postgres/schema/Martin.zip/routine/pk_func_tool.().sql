create function "Martin".pk_func_tool() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_tool');
  RETURN new;
END;
$$
;
