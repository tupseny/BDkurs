create function "Martin".pk_func_un_wr() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_un_wr');
  RETURN new;
END;
$$
;
