create function "Martin".pk_func_item() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_item');
  RETURN new;
END;
$$
;
