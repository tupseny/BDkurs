create function "Martin".pk_func_bi_mob() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_bi_mob');
  RETURN new;
END;
$$
;
