create function "Martin".pk_func_mob() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_mob');
  RETURN new;
END;
$$
;
