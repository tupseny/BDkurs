create function "Martin".pk_func_precip() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_precip');
  RETURN new;
END;
$$
;
