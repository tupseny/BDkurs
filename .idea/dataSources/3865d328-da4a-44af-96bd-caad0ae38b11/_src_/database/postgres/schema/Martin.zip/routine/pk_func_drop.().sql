create function "Martin".pk_func_drop() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_drop');
  RETURN new;
END;
$$
;
