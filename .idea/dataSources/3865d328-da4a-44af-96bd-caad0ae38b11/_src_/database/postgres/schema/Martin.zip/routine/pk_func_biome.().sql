create function "Martin".pk_func_biome() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_biome');
  RETURN new;
END;
$$
;
