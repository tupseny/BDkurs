create function "Martin".pk_func_wr_bi() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_wr_bi');
  RETURN new;
END;
$$
;
