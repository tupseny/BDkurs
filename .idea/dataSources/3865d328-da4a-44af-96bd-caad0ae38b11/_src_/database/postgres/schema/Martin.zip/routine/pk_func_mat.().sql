create function "Martin".pk_func_mat() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_mat');
  RETURN new;
END;
$$
;
