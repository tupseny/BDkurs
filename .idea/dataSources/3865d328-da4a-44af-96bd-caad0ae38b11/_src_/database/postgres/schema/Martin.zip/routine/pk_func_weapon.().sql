create function "Martin".pk_func_weapon() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_weapon');
  RETURN new;
END;
$$
;
