create function "Martin".pk_func_word() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_word');
  RETURN new;
END;
$$
;
