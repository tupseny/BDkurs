create function "Martin".pk_func_inv() returns trigger
language plpgsql
as $$
BEGIN
  new.SLOT = nextval('pk_seq_inv');
  RETURN new;
END;
$$
;
