create function "Martin".pk_func_block() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_block');
  RETURN new;
END;
$$
;
