create function "Martin".pk_func_player() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_player');
  RETURN new;
END;
$$
;
