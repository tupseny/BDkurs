create function "Martin".pk_func_effect() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_effect');
  RETURN new;
END;
$$
;
