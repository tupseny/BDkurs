create function "Martin".pk_func_dmg_type() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_dmg_type');
  RETURN new;
END;
$$
;
