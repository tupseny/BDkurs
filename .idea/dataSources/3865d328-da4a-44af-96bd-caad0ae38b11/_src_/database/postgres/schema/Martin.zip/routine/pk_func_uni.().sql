create function "Martin".pk_func_uni() returns trigger
language plpgsql
as $$
BEGIN
  new.ID = nextval('pk_seq_uni');
  RETURN new;
END;
$$
;
