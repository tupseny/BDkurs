create function timedate_pl(time without time zone, date) returns timestamp without time zone
language sql
as $$
select ($2 + $1)
  $$;
