create function quote_literal(anyelement) returns text
language sql
as $$
select pg_catalog.quote_literal($1::pg_catalog.text)
  $$;
