create function interval_pl_time(interval, time without time zone) returns time without time zone
language sql
as $$
select $2 + $1
  $$;
