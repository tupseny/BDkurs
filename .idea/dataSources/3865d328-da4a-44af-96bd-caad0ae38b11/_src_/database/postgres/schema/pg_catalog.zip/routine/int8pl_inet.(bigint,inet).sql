create function int8pl_inet(bigint, inet) returns inet
language sql
as $$
select $2 + $1
  $$;
