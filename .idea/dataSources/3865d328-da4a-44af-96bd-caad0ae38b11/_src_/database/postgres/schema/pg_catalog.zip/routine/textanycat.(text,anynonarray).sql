create function textanycat(text, anynonarray) returns text
language sql
as $$
select $1 || $2::pg_catalog.text
$$;
