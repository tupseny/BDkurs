create function pg_relation_size(regclass) returns bigint
language sql
as $$
select pg_catalog.pg_relation_size($1, 'main')
  $$;
