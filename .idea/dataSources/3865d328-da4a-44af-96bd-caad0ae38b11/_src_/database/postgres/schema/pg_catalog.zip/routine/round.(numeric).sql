create function round(numeric) returns numeric
language sql
as $$
select pg_catalog.round($1,0)
  $$;
