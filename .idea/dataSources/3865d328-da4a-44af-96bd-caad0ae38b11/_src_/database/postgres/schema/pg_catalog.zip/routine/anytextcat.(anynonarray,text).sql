create function anytextcat(anynonarray, text) returns text
language sql
as $$
select $1::pg_catalog.text || $2
$$;
