create function xpath_exists(text, xml) returns boolean
language sql
as $$
select pg_catalog.xpath_exists($1, $2, '{}'::pg_catalog.text[])
  $$;
