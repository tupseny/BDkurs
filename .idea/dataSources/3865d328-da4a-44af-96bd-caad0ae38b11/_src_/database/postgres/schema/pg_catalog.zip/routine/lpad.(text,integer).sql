create function lpad(text, integer) returns text
language sql
as $$
select pg_catalog.lpad($1, $2, ' ')
  $$;
