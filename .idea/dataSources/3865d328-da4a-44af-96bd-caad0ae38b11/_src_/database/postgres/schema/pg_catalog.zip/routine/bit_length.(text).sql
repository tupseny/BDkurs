create function bit_length(text) returns integer
language sql
as $$
select pg_catalog.octet_length($1) * 8
  $$;
