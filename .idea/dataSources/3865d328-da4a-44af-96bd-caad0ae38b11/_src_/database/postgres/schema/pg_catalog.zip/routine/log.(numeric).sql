create function log(numeric) returns numeric
language sql
as $$
select pg_catalog.log(10, $1)
  $$;
