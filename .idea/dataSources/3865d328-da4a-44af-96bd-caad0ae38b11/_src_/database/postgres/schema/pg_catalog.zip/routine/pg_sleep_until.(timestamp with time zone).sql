create function pg_sleep_until(timestamp with time zone) returns void
language sql
as $$
select pg_catalog.pg_sleep(extract(epoch from $1) operator(pg_catalog.-) extract(epoch from pg_catalog.clock_timestamp()))
  $$;
