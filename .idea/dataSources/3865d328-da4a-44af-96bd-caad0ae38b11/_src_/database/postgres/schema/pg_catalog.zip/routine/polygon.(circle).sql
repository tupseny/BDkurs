create function polygon(circle) returns polygon
language sql
as $$
select pg_catalog.polygon(12, $1)
  $$;
