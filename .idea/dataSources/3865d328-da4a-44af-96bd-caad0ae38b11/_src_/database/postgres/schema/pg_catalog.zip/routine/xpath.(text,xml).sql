create function xpath(text, xml) returns xml[]
language sql
as $$
select pg_catalog.xpath($1, $2, '{}'::pg_catalog.text[])
  $$;
