create function rpad(text, integer) returns text
language sql
as $$
select pg_catalog.rpad($1, $2, ' ')
  $$;
