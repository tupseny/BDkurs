create function path_contain_pt(path, point) returns boolean
language sql
as $$
select pg_catalog.on_ppath($2, $1)
  $$;
