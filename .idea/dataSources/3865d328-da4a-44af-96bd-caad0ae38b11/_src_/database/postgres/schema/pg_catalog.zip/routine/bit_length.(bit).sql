create function bit_length(bit) returns integer
language sql
as $$
select pg_catalog.length($1)
  $$;
